const btn1=document.querySelector(".drum");
btn1.addEventListener("click",()=>{
    document.querySelector("#drumaudio").play();

})

const btn2=document.querySelector(".guiter");
btn2.addEventListener("click",()=>{
    document.querySelector("#guiteraudio").play();

})
const btn3=document.querySelector(".piano");
btn3.addEventListener("click",()=>{
    document.querySelector("#pianoaudio").play();

})
const btn4=document.querySelector(".trumpet");
btn4.addEventListener("click",()=>{
    document.querySelector("#trumpetaudio").play();

})
const btn5=document.querySelector(".flute");
btn5.addEventListener("click",()=>{
    document.querySelector("#fluteaudio").play();

})
const btn6=document.querySelector(".sitar");
btn6.addEventListener("click",()=>{
    document.querySelector("#sitaraudio").play();

})
const btn7=document.querySelector(".volin");
btn7.addEventListener("click",()=>{
    document.querySelector("#volinaudio").play();

})
const btn8=document.querySelector(".marcos");
btn8.addEventListener("click",()=>{
    document.querySelector("#maracasaudio").play();

})